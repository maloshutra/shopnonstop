export const environment = {
  production: true,
  apiUrl: 'https://shopnonstop.onrender.com'
};
